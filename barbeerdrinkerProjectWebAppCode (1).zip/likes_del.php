<?php
include("model/Likes.php");
//echo $_GET['id'];
         $likes = new Likes();
         //echo "hello";die; 
         $result = $likes->delete($_GET['drinker'],$_GET['beer']);
         echo $result;

         ?>