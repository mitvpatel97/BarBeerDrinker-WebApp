<?php

include("model/Sells.php");
//echo $_GET['id'];
         $sells = new Sells();
         //echo "hello";die; 
         $result = $sells->delete($_GET['barid'],$_GET['itemid']);
         echo $result;

?>