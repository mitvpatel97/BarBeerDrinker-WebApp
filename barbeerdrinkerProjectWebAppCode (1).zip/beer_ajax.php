<?php 
//print_r($_POST);
include("model/Bear.php");
        $beers = new Bear(); 

if($_POST['action']=="update") {
unset($_POST['action']);
$id=$_POST['id'];
unset($_POST['id']);
//print_r($_POST);
echo $beers->update($_POST,$id);

}else if ($_POST['action']=="add"){
	unset($_POST['action']);
	unset($_POST['id']);
	//print_r($_POST);
	//die;
	echo $beers->add($_POST);
}else{

}

?>