<?php 
//print_r($_POST);
include("model/Drinkers.php");
        $drinkers = new Drinkers(); 

if($_POST['action']=="update") {
unset($_POST['action']);
$id=$_POST['id'];
unset($_POST['id']);
//print_r($_POST);
echo $drinkers->update($_POST,$id);

}else if ($_POST['action']=="add"){
	unset($_POST['action']);
	unset($_POST['id']);
	echo $drinkers->add($_POST);
}else{

}

?>