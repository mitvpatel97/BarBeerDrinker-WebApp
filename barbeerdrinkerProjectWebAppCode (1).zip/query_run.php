<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Bar</title>

    <!-- Bootstrap core CSS-->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Page level plugin CSS-->
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin.css" rel="stylesheet">
  </head>

  <body id="page-top">

    <?php 
      include ("layout/navigation-bar.php");
    ?>
    <div id="wrapper">
     
     
      <?php 
        include ("layout/sidebar.php");
      ?>
      <?php 
      if($_POST){
        $q=$_POST["q"];
          include("model/Execute.php");
          $executor = new Execute(); 
         $tuples = $executor->exequery($q);
        }
      ?>
 <div id="content-wrapper">

        <div class="container-fluid">
<div class="container">
      <div class="card  mx-auto mt-10">
        <div class="card-header">Quert Executor</div>
        <div class="card-body">
          <form  action="query_run.php" method="POST">
            
            <div class="form-group">
              <label for="query">Query</label>
              <div class="form-label-group">
                <textarea  id="query" class="form-control"  name="q" required="required" rows="3"></textarea>
                
              </div>
            </div>
            <button type="submit" class="btn btn-primary">Execute</button>
           
          </form>
          
        </div>
      </div>
    </div>
        <?php if($tuples) { ?>  
<div class="card mb-3">
              <div class="card-header">
                <i class="fas fa-table"></i>
                All Drinkers</div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                   <tbody>
                      <?php 
                        if( $tuples ){
                          foreach ($tuples as $tuple) {
                           echo "<tr class='clickable-row' data-href='?id=".$tuple["id"]."' style='cursor: pointer'>";
                          foreach($tuple as $key => $value){
                           
                            echo "<td>" . $value . "</td>";
                          }
                            echo "<tr>";
                          }
                        }

                      ?>
                       </tbody>

                    </tbody>
                  </table>
                </div>
              </div>
              <?php }else if($tuples==false) {
              echo "<p>error in execute</ p>"; 
            } ?>
              <!-- <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div> -->
            </div>


</div>

        <!-- /.container-fluid -->

        <!-- Sticky Footer -->
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © Your Website 2018</span>
            </div>
          </div>
        </footer>


 </div>
      <!-- /.content-wrapper -->
         </div>
    <!-- /#wrapper -->

        

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="login.html">Logout</a>
          </div>
        </div>
      </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>

   
    <script src="js/demo/chart-bar-demo.js"></script>
   
    <!-- Make table row clickable -->
    <script type="text/javascript">
    $(document).ready(function($) {
        $(".clickable-row").click(function() {
            window.location = $(this).data("href");
        });
    });
    </script>
  </body>

</html>
