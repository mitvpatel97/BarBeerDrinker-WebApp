<?php

include("model/Transaction.php");
//echo $_GET['id'];
         $transactions = new Transactions();
         //echo "hello";die; 
         $result = $transactions->delete($_GET['id']);
         echo $result;

?>