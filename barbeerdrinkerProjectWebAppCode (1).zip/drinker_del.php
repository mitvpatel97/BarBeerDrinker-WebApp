<?php

include("model/Drinkers.php");
//echo $_GET['id'];
         $Drinker = new Drinkers();
         //echo "hello";die; 
         $result = $Drinker->delete($_GET['id']);
         echo $result;

?>