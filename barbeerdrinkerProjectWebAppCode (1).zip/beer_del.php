<?php

include("model/Bear.php");
//echo $_GET['id'];
         $beers = new Bear();
         //echo "hello";die; 
         $result = $beers->delete($_GET['id']);
         echo $result;

?>