<?php 
//print_r($_POST);
include("model/Sells.php");
        $sells = new Sells(); 

if($_POST['action']=="update") {
unset($_POST['action']);
//print_r($_POST);die;
echo $sells->update($_POST);

}else if ($_POST['action']=="add"){

	unset($_POST['action']);
	//print_r($_POST);die;
	echo $sells->add($_POST);
}else{

}

?>