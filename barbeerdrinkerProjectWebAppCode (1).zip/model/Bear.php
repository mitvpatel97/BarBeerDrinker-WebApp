<?php
	require_once "MysqlConnection.php";

	class Bear{
		const tableName ="items";

		public function __construct(){
			$this->conn =  MysqlConnection::getConn(); 
		}
		public function getAllBears(){
			$query = "SELECT * FROM " . self::tableName;
			$result = mysqli_query( $this->conn, $query );
			if( mysqli_num_rows( $result ) < 1)
				return false;
			return $result;
				
		}

public function getBeer($id){
			$query = "SELECT * FROM " . self::tableName . " where itemid=$id";
			$result = mysqli_query( $this->conn, $query );
			if( mysqli_num_rows( $result ) < 1)
                                return false;
                        return $result;
		}

		public function add($beerAry) {
				foreach($beerAry as $key =>$value) {
					$beerAry[$key]='"'.$value.'"';
				}
			$beerStr=implode($beerAry,",");
			
			$query= "INSERT INTO " . self::tableName . " (`itemname`, `type`, `price`, `manufacture`) VALUES  ($beerStr)";
			//echo $query;die;
			$result = mysqli_query( $this->conn, $query );
			if($result){
					return true;
			}else{
					 return mysqli_error($conn);
			}

		}
		public function update($beerAry,$id) {
			$beerStr="";
			foreach($beerAry as $key =>$value) {
				if($key!="manufacture")
					$beerStr.=$key.'="'.$value.'", ';
				else
					$beerStr.=$key.'="'.$value.'" ';
				}
				//echo $drinkersStr;die;
			//$drinkersStr=implode($drinkerAry,",");
			$query= "Update " . self::tableName . " SET ".$beerStr." where itemid=".$id;
			$result = mysqli_query( $this->conn, $query );
			//echo $query;
			//die;
			if($result){
					return true;
			}else{
					 return mysqli_error($conn);
			}	

		}


		public function delete($id){
			$query = "delete from ". self::tableName . " where itemid=".$id;
			//echo $query;die;
			$result = mysqli_query( $this->conn, $query );
			if( $result)
                return true;
            else
                 return mysqli_error($this->conn);
		}
		
		public function getTopBars($beerid) {
				$query = "select barname,count(*)  as total from transactions left join bars on transactions.barId=bars.barID where transactions.itemId=".$beerid." group by transactions.barId order by total desc";
			$result = mysqli_query( $this->conn, $query );
			if( mysqli_num_rows( $result ) < 1)
				return false;
			return $result;
				
		}


public function getTopDrinkers($beerid) {
				$query = "select name,count(*) as total from transactions left join drinker on transactions.drinkerid=drinker.id where itemId=".$beerid."  group by drinkerid order by total desc";
			$result = mysqli_query( $this->conn, $query );
			if( mysqli_num_rows( $result ) < 1)
				return false;
			return $result;
				
		}


public function getTopHours($beerid) {
				$query = "select hour(time_issued) as hours , count(*) as total from transactions where itemId=".$beerid." group by hour(time_issued) order by total desc";
			$result = mysqli_query( $this->conn, $query );
			if( mysqli_num_rows( $result ) < 1)
				return false;
			return $result;
				
		}



	}

