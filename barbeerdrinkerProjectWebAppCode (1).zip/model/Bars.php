<?php
	require_once "MysqlConnection.php";

	class Bars{
		const tableName = "bars";

		public function __construct(){
			$this->conn =  MysqlConnection::getConn(); 
		}



		public function getAllBars(){
			$query = "SELECT * FROM " . self::tableName;
			$result = mysqli_query( $this->conn, $query );
			if( mysqli_num_rows( $result ) < 1)
				return false;
			return $result;
		}

public function getBar($barID){
			$query = "SELECT * FROM " . self::tableName . " where barID=$barID";
			$result = mysqli_query( $this->conn, $query );
			if( mysqli_num_rows( $result ) < 1)
                                return false;
                        return $result;
		}

		public function add($barAry) {
				foreach($barAry as $key =>$value) {
					$barAry[$key]='"'.$value.'"';
				}
			$barStr=implode($barAry,",");
			//echo $barStr;die;
			
			$query= "INSERT INTO " . self::tableName . " (`barname`,`license` ,`address`, `city`, `state`, `phone`,`open_time`,`close_time`) VALUES  ($barStr)";
			//die;
			$result = mysqli_query( $this->conn, $query );
			if($result){
					return true;
			}else{
					 return mysqli_error($conn);
			}

		}
		public function update($barAry,$id) {
			$barStr="";
			foreach($barAry as $key =>$value) {
				if($key!="close_time")
					$barStr.=$key.'="'.$value.'", ';
				else
					$barStr.=$key.'="'.$value.'" ';
				}
				//echo $drinkersStr;die;
			//$drinkersStr=implode($drinkerAry,",");
			 $query= "Update " . self::tableName . " SET ".$barStr." where barID=".$id;
			//die;
			$result = mysqli_query( $this->conn, $query );
			if($result){
					return true;
			}else{
					 return mysqli_error($conn);
			}	

		}


		public function delete($id){
			$query = "delete from ". self::tableName . " where barID=".$id;
			$result = mysqli_query( $this->conn, $query );
			if( $result)
                return true;
            else
                 return mysqli_error($this->conn);
		}
		
		public function getTopdrinkers($barid) {
			//$barid=15;
				$query = "select drinker, sum(price) as total 
						from (select frequents.drinkerid,drinker,transactions.price  
						from  frequents 
						left join  transactions 
						on frequents.drinkerid =transactions.drinkerId
						where frequents.barid=".$barid." ) as a
						group by a.drinkerid order by sum(a.price) desc";
			$result = mysqli_query( $this->conn, $query );
			if( mysqli_num_rows( $result ) < 1)
				return false;
			return $result;
				
		}


public function getPopularBear($barid) {
	//$barid=600;
				$query = "select itemname,likes from (select barid,itemname from sells left join items on sells.itemid=items.itemid where barid=".$barid.") as a 
left join (select bear,count(*) as likes from likes group by bear  ) as b   ON a.itemname=b.bear group by bear";
			$result = mysqli_query( $this->conn, $query );
			if( mysqli_num_rows( $result ) < 1)
				return false;
			return $result;
				
		}

		public function getManufactures($barid){
			$query = "select manufacture,count(*) as total from transactions left join items on transactions.itemId=items.itemid  where transactions.barId=195  group by transactions.itemId order by total desc limit 5";
			$result = mysqli_query( $this->conn, $query );
			if( mysqli_num_rows( $result ) < 1)
				return false;
			return $result;

		}
	}

