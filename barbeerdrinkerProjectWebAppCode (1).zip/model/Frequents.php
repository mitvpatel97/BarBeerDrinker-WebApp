<?php
	require_once "MysqlConnection.php";
	class Frequents{
		const tableName = "frequents";
		public function __construct(){
			$this->conn = MysqlConnection::getConn();
		}

		
		public function getAllfrequents(){
			 $query = "SELECT * FROM " . self::tableName;
			 //echo $query;die;
			$result = mysqli_query( $this->conn, $query );
			if( mysqli_num_rows( $result ) < 1)
				return false;
			return $result;
				
		}

/*public function getSell($barid,$itemid){
			$query = "SELECT * FROM " . self::tableName . " where barid=".$barid." and itemid=".$itemid ;
			$result = mysqli_query( $this->conn, $query );
			if( mysqli_num_rows( $result ) < 1)
                                return false;
                        return $result;
		}*/

		public function add($frequentsAry) {

			//$querydrinker=""
			$frequentsAry['barname']="xyz";
			$frequentsAry['drinker']="xyz";
				foreach($frequentsAry as $key =>$value) {
					$frequentsAry[$key]='"'.$value.'"';
				}
			$frequentsStr=implode($frequentsAry,",");
			
			$query= "INSERT INTO " . self::tableName . " (`drinkerid`, `barid`,`barname`,`drinker`) VALUES  ($frequentsStr)";
			//echo $query;die;
			$result = mysqli_query( $this->conn, $query );
			if($result){
					return true;
			}else{
					 return mysqli_error($this->conn);
			}

		}
		


		public function delete($drinker,$bar){
			$query = "delete from ". self::tableName . " where  drinkerid=".$drinker." and barid=".$bar;
			//echo $query;die;
			$result = mysqli_query( $this->conn, $query );
			if( $result)
                return true;
            else
                 return mysqli_error($this->conn);
		}
	}
