<?php
	require_once "MysqlConnection.php";
	class Likes{
		const tableName = "likes";
		public function __construct(){
			$this->conn = MysqlConnection::getConn();
		}

		
		public function getAllLikes(){
			 $query = "SELECT * FROM " . self::tableName;
			 //echo $query;die;
			$result = mysqli_query( $this->conn, $query );
			if( mysqli_num_rows( $result ) < 1)
				return false;
			return $result;
				
		}

/*public function getSell($barid,$itemid){
			$query = "SELECT * FROM " . self::tableName . " where barid=".$barid." and itemid=".$itemid ;
			$result = mysqli_query( $this->conn, $query );
			if( mysqli_num_rows( $result ) < 1)
                                return false;
                        return $result;
		}*/

		public function add($likesAry) {
				foreach($likesAry as $key =>$value) {
					$likesAry[$key]='"'.$value.'"';
				}
			$likesStr=implode($likesAry,",");
			
			$query= "INSERT INTO " . self::tableName . " (`Drinker`, `bear`) VALUES  ($likesStr)";
			//echo $query;die;
			$result = mysqli_query( $this->conn, $query );
			if($result){
					return true;
			}else{
					 return mysqli_error($this->conn);
			}

		}
		


		public function delete($drinker,$beer){
			$query = "delete from ". self::tableName . " where  Drinker='".$drinker."'  and bear='".$beer."'";
			//echo $query;die;
			$result = mysqli_query( $this->conn, $query );
			if( $result)
                return true;
            else
                 return mysqli_error($this->conn);
		}
	}
