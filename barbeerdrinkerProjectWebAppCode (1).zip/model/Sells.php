<?php
	require_once "MysqlConnection.php";
	class Sells{
		const tableName = "sells";
		public function __construct(){
			$this->conn = MysqlConnection::getConn();
		}

		
		public function getAllSells(){
			 $query = "SELECT sells.barid,sells.itemid,sells.price,bars.barname,items.itemname FROM " . self::tableName ." left Join bars on sells.barid=bars.barID 
			 left join items on sells.itemid=items.itemid" ;
			 //echo $query;die;
			$result = mysqli_query( $this->conn, $query );
			if( mysqli_num_rows( $result ) < 1)
				return false;
			return $result;
				
		}

public function getSell($barid,$itemid){
			$query = "SELECT * FROM " . self::tableName . " where barid=".$barid." and itemid=".$itemid ;
			$result = mysqli_query( $this->conn, $query );
			if( mysqli_num_rows( $result ) < 1)
                                return false;
                        return $result;
		}

		public function add($sellsAry) {
				foreach($sellsAry as $key =>$value) {
					$sellsAry[$key]='"'.$value.'"';
				}
			$sellStr=implode($sellsAry,",");
			
			$query= "INSERT INTO " . self::tableName . " (`barid`, `itemid`, `price`) VALUES  ($sellStr)";
			//echo $query;die;
			$result = mysqli_query( $this->conn, $query );
			if($result){
					return true;
			}else{
					 return mysqli_error($this->conn);
			}

		}
		public function update($sellAry) {
			$sellStr="";
				//echo $drinkersStr;die;
			//$drinkersStr=implode($drinkerAry,",");
			$query= "Update " . self::tableName . " SET price=".$sellAry['price']." where barid=".$sellAry['barid']." and itemid=".$sellAry['itemid'];
			$result = mysqli_query( $this->conn, $query );
			//echo $query;
			//die;
			if($result){
					return true;
			}else{
					 return mysqli_error($this->conn);
			}	

		}


		public function delete($barid,$itemid){
			$query = "delete from ". self::tableName . " where  barid=".$barid." and itemid=".$itemid;
			//echo $query;die;
			$result = mysqli_query( $this->conn, $query );
			if( $result)
                return true;
            else
                 return mysqli_error($this->conn);
		}
	}
