<?php
require_once "MysqlConnection.php";
	require_once "Bars.php";

class Common{
		public function __construct(){
			$this->conn = MysqlConnection::getConn();
		}
		public function getDrinkerDoupdown(){
			
				$query = "SELECT id,name FROM drinker" ;
			//die;
			$result = mysqli_query( $this->conn, $query );
			if( mysqli_num_rows( $result ) < 1)
				return false;
			return $result;
		}

		public function getDrinkerNameDoupdown(){
			
				$query = "SELECT name FROM drinker" ;
			//die;
			$result = mysqli_query( $this->conn, $query );
			if( mysqli_num_rows( $result ) < 1)
				return false;
			return $result;
		}
		public function getBarDoupdown(){
				$query = "SELECT barID,barname FROM bars" ;
			$result = mysqli_query( $this->conn, $query );
			if( mysqli_num_rows( $result ) < 1)
				return false;
			return $result;
		}

		public function getBarNameDoupdown(){
				$query = "SELECT barname FROM bars" ;
			$result = mysqli_query( $this->conn, $query );
			if( mysqli_num_rows( $result ) < 1)
				return false;
			return $result;
		}

		public function getBeerDoupdown(){
				$query = "SELECT itemid,itemname FROM items" ;
			$result = mysqli_query( $this->conn, $query );
			if( mysqli_num_rows( $result ) < 1)
				return false;
			return $result;
		}

		public function getBeerNameDoupdown(){
				$query = "SELECT itemname FROM items" ;
			$result = mysqli_query( $this->conn, $query );
			if( mysqli_num_rows( $result ) < 1)
				return false;
			return $result;
		}
	}
?>