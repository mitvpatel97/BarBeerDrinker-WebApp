<?php
	require_once "MysqlConnection.php";

	class Execute{
		public function __construct(){
			$this->conn =  MysqlConnection::getConn(); 
		}
		public function exequery($q) {

			$query=trim($q);
			try {
					$result = mysqli_query( $this->conn, $query );
					if( mysqli_num_rows( $result ) < 1)
						return false;
					return $result;
		   }catch(Exception $e) {
			return false;	
		}
				
		}


	}

