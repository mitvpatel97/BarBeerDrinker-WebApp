<?php 
	require_once "MysqlConnection.php";

	class Drinkers{
		const tableName = "drinker";
		public function __construct(){
			$this->conn =  MysqlConnection::getConn(); 
		}
		public function getAllDrinkers(){
			$query = "SELECT * FROM " . self::tableName;
			$result = mysqli_query( $this->conn, $query );
			if( mysqli_num_rows( $result ) < 1)
				return false;
			return $result;
				
		}
		public function getDrinker($drinkerID){
			$query = "SELECT * FROM " . self::tableName . " where id=$drinkerID";
			$result = mysqli_query( $this->conn, $query );
			if( mysqli_num_rows( $result ) < 1)
                                return false;
                        return $result;
		}

		public function getBeer($drinkerID){

			$query = "select itemname,count(*) as total from transactions left join items on transactions.itemId=items.itemid  where drinkerId=".$drinkerID."  group by transactions.itemId order by total desc limit 5";
			//die;
			$result = mysqli_query( $this->conn, $query );
			if( mysqli_num_rows( $result ) < 1)
                                return false;
                        return $result;
		}
		public function add($drinkerAry) {
				foreach($drinkerAry as $key =>$value) {
					$drinkerAry[$key]='"'.$value.'"';
				}
			$drinkersStr=implode($drinkerAry,",");
			
			$query= "INSERT INTO " . self::tableName . " (`name`, `address`, `city`, `state`, `phone`) VALUES  ($drinkersStr)";
			$result = mysqli_query( $this->conn, $query );
			if($result){
					return true;
			}else{
					 return mysqli_error($conn);
			}

		}
		public function update($drinkerAry,$id) {
			$drinkersStr="";
			foreach($drinkerAry as $key =>$value) {
				if($key!="phone")
					$drinkersStr.=$key.'="'.$value.'", ';
				else
					$drinkersStr.=$key.'="'.$value.'" ';
				}
				//echo $drinkersStr;die;
			//$drinkersStr=implode($drinkerAry,",");
			$query= "Update " . self::tableName . " SET ".$drinkersStr." where id=".$id;
			$result = mysqli_query( $this->conn, $query );
			if($result){
					return true;
			}else{
					 return mysqli_error($conn);
			}	

		}


		public function delete($drinkerID){
			$query = "delete from drinker where id=".$drinkerID;
			$result = mysqli_query( $this->conn, $query );
			if( $result)
                return true;
            else
                 return mysqli_error($this->conn);
		}
		public function getSpendings($drinkerID) {
			$query = "select barname,sum(price) as total from transactions left join bars ON transactions.barId=bars.barID  where drinkerid=".$drinkerID." group by transactions.barId;";
			$result = mysqli_query( $this->conn, $query );
			if( mysqli_num_rows( $result ) < 1)
                                return false;
                        return $result;
		} 

	}
	/*
	$drinkers = new Drinkers();
	$tuples = $drinkers->getAllDrinkers();
	if( !$tuples )
		die("false");
	$row = mysqli_fetch_assoc( $tuples ) ;
	*/
