<?php
	class MysqlConnection{
		const endpoint = "projectbar.cqut1tbpokda.us-east-2.rds.amazonaws.com";
		const username = "projectbar";
		const password = "project123";
		const dbname = "projectbardb";
		public static function getConn(){
			$conn = mysqli_connect( self::endpoint, self::username, self::password, self::dbname);
			if (!$conn) 
				throw new Exception( "MySQL Connection error : ".mysqli_connect_error() );
			return $conn;
		}
	}


	// $conn = MysqlConnection::getConn();
