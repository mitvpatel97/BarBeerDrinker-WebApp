<?php
	require_once "MysqlConnection.php";
	require_once "Bars.php";
	class Transactions{
		const tableName = "transactions";
		public function __construct(){
			$this->conn = MysqlConnection::getConn();
		}

		public function getDetailedTransOfDrinker($drinkerID){
			$query = "SELECT t.*,b.barname  FROM " . self::tableName . " as t LEFT JOIN ".Bars::tableName." as b ON t.barId=b.barId  where drinkerID=$drinkerID order by t.time_issued" ;
			$result = mysqli_query( $this->conn, $query );
                        if( mysqli_num_rows( $result ) < 1)
                                return false;
                        return $result;
		}	

		public function getAllTrans(){
			 $query = "SELECT transactions.*,bars.barname,items.itemname,drinker.name FROM " . self::tableName ."
			  left Join drinker on transactions.drinkerId=drinker.id
			 left Join bars on transactions.barId=bars.barID 
			 left join items on transactions.itemId=items.itemid" ;
			 //die;
			$result = mysqli_query( $this->conn, $query );
			if( mysqli_num_rows( $result ) < 1)
				return false;
			return $result;
				
		}

public function getTrans($id){
			$query = "SELECT * FROM " . self::tableName . " where transactionId=$id";
			$result = mysqli_query( $this->conn, $query );
			if( mysqli_num_rows( $result ) < 1)
                                return false;
                        return $result;
		}

		public function add($transAry) {
				foreach($transAry as $key =>$value) {
					$transAry[$key]='"'.$value.'"';
				}
			$tranStr=implode($transAry,",");
			
			$query= "INSERT INTO " . self::tableName . " (`drinkerId`, `barId`, `billId`, `itemId`,`price`,`time_issued`) VALUES  ($tranStr)";
			//echo $query;die;
			$result = mysqli_query( $this->conn, $query );
			if($result){
					return true;
			}else{
					 return mysqli_error($conn);
			}

		}
		public function update($beerAry,$id) {
			$beerStr="";
			foreach($beerAry as $key =>$value) {
				if($key!="manufacture")
					$beerStr.=$key.'="'.$value.'", ';
				else
					$beerStr.=$key.'="'.$value.'" ';
				}
				//echo $drinkersStr;die;
			//$drinkersStr=implode($drinkerAry,",");
			$query= "Update " . self::tableName . " SET ".$beerStr." where transactionId=".$id;
			$result = mysqli_query( $this->conn, $query );
			//echo $query;
			//die;
			if($result){
					return true;
			}else{
					 return mysqli_error($conn);
			}	

		}


		public function delete($id){
			$query = "delete from ". self::tableName . " where transactionId=".$id;
			//echo $query;die;
			$result = mysqli_query( $this->conn, $query );
			if( $result)
                return true;
            else
                 return mysqli_error($this->conn);
		}
	}
