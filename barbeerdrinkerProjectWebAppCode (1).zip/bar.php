<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Bar</title>

    <!-- Bootstrap core CSS-->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Page level plugin CSS-->
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin.css" rel="stylesheet">
  </head>

  <body id="page-top">

    <?php 
      include ("layout/navigation-bar.php");
    ?>
    <div id="wrapper">
      <?php 
     // error_reporting(E_ALL);

        include ("layout/sidebar.php");
      ?>


 <?php 
        if($_GET) { 
        if(isset($_GET["id"])){
          $barid=$_GET["id"];
        } else {
          $barid=15;
        } 
      }else{
      $barid=15;
    }
    //echo $barid;die;
      ?>
      <?php
        include("model/Bars.php");
        $bars = new Bars(); 
         $tuples = $bars->getTopdrinkers($barid);
         //print_r($tuples);
         $drinkers=array();
         $price=array();
         $bearRcd=$bars->getPopularBear($barid);

         $bearAry=array();
         $likesAry=array();
$ManufacturerRcd=$bars->getManufactures($barid);

         $manuAry=array();
         $countAry=array();


         if( $tuples ){
                          foreach ($tuples as $tuple) {
                          //print_r($tuple);
                          $drinkers[]='"'.$tuple['drinker'].'"';
                          if($tuple['total']==null)
                          $price[]=0;
                          else
                          $price[]=$tuple['total'];
                          
                        }
                      }
                      //print_r($drinkers);
                    $bar1x=  implode($drinkers,',');
                    $bar1y= implode($price,',');

                      foreach($bearRcd as $bear){

                          //print_r($tuple);
                          $bearAry[]='"'.$bear['itemname'].'"';
                          if($bear['likes']==null)
                          $likesAry[]=0;
                          else
                          $likesAry[]=$bear['likes'];
        }
     $bar2x=  implode($bearAry,',');
      $bar2y=  implode($likesAry,',');


      foreach($ManufacturerRcd as $manu){

                          //print_r($tuple);
                          $manuAry[]='"'.$manu['manufacture'].'"';
                          if($manu['total']==null)
                          $countAry[]=0;
                          else
                          $countAry[]=$manu['total'];
        }
     $bar3x=  implode($manuAry,',');
      $bar3y=  implode($countAry,',');
      ?>

      <script>
        var bar1x=[<?php echo $bar1x; ?>];
        var bar1y=[<?php echo $bar1y; ?>];

        var bar2x=[<?php echo $bar2x; ?>];
        var bar2y=[<?php echo $bar2y; ?>];
        var bar3x=[<?php echo $bar3x; ?>];
        var bar3y=[<?php echo $bar3y; ?>];


        console.log(bar1x);
        console.log(bar1y);
      </script>
 <div id="content-wrapper">

        <div class="container-fluid">

           <div class="row">
            <div class="col-lg-6">
              <div class="card mb-3">
                <div class="card-header">
                  <i class="fas fa-chart-bar"></i>
                  Drinker Graph</div>
                <div class="card-body">
                  <canvas id="myBarChart" width="100%" height="50"></canvas>
                </div>
                <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
              </div>
            </div>
               <div class="col-lg-6">
              <div class="card mb-3">
                <div class="card-header">
                  <i class="fas fa-chart-bar"></i>
                  Popular Beer Graph</div>
                <div class="card-body">
                  <canvas id="myBarChart1" width="100%" height="50"></canvas>
                </div>
                <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
              </div>
            </div>
          </div>



<div class="row">
            <div class="col-lg-6">
              <div class="card mb-3">
                <div class="card-header">
                  <i class="fas fa-chart-bar"></i>
                  Manufactures Graph</div>
                <div class="card-body">
                  <canvas id="myBarChart2" width="100%" height="50"></canvas>
                </div>
                <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
              </div>
            </div>
              
          </div>
</div>

        <!-- /.container-fluid -->

        <!-- Sticky Footer -->
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © Your Website 2018</span>
            </div>
          </div>
        </footer>


 </div>
      <!-- /.content-wrapper -->
         </div>
    <!-- /#wrapper -->

        

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="login.html">Logout</a>
          </div>
        </div>
      </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>

   
    <script src="js/demo/chart-bar-demo.js"></script>
   
    <!-- Make table row clickable -->
    <script type="text/javascript">
    $(document).ready(function($) {
        $(".clickable-row").click(function() {
            window.location = $(this).data("href");
        });
    });
    </script>
  </body>

</html>
