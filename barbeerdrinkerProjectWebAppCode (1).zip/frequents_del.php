<?php
include("model/Frequents.php");
//echo $_GET['id'];
         $frequents = new Frequents();
         //echo "hello";die; 
         $result = $frequents->delete($_GET['drinkerid'],$_GET['barid']);
         echo $result;

         ?>