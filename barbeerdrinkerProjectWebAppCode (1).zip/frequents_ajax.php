<?php 
//print_r($_POST);
include("model/Frequents.php");
//include("model/Bear.php");
//include("model/Drinkers.php");

        $frequents = new Frequents(); 
       // $beer= new Bear();
        //$drinkers= new Drinkers();

if($_POST['action']=="update") {
unset($_POST['action']);
//print_r($_POST);die;
echo $sells->update($_POST);

}else if ($_POST['action']=="add"){

	unset($_POST['action']);
	//$beerRcd=$beer->getBeer($itemid);
	//print_r($beerRcd);
	/*foreach($beerRcd as $tuple){
		echo $tuple['itemname'];
	}*/
	//$drinkerRcd=$bar->getDrinker($barid);
	

	//print_r($_POST);die;
	echo $frequents->add($_POST);
}else{

}

?>