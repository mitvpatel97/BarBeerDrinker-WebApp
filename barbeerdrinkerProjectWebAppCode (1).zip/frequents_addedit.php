<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Drinker</title>

    <!-- Bootstrap core CSS-->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Page level plugin CSS-->
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin.css" rel="stylesheet">
  </head>

  <body id="page-top">

    <?php 
      include ("layout/navigation-bar.php");
    ?>
    <div id="wrapper">
     
     
      <?php 
        include ("layout/sidebar.php");
      ?>
      <?php 
     if($_GET){
        include("model/Sells.php");
        $sells = new Sells(); 
        $barid=$_GET['barid'];
        $itemid=$_GET['itemid'];
       $temp = $sells->getSell($barid,$itemid);
       $sellsAry = mysqli_fetch_assoc($temp);
     }
      include("model/Common.php");
       $common = new Common();
       $drinkerAry=$common->getDrinkerDoupdown();
      // $barAry=$common->getBarDoupdown();
       $beerAry=$common->getBeerDoupdown();

       
        //print_r($drinkerAry);
        //die;
      
      ?>
 <div id="content-wrapper">

        <div class="container-fluid">
<div class="container">
      <div class="card  mx-auto mt-10">
        <div class="card-header">Frequent's Form</div>
        <div class="card-body">
          <!--<form  action="drinker_update.php" method="POST">-->
            <!--<form>-->
              <?php if(!isset($_GET['barid'])) { ?>
             <div class="form-group">
              <div class="form-row">
               

                <div class="col-md-6">
                 <div class="form-label-group">
                  <!--  <label for="sel1">Select list (select one):</label>-->
      <select class="form-control" id="bar_id" name="bar_id">
        <option value="0">Select drinker </option>
     <?php  if( $drinkerAry ){
                          foreach ($drinkerAry   as $tuple) {
                          echo '<option value="'.$tuple['id'].'">'.$tuple['name'].'</option>';
                        }
                      }
                      ?>
      </select>
                   <!-- <label for="name">Drinker ID</label>-->
                  </div>
                
                </div>

                
                 <div class="col-md-6">
                 <div class="form-label-group">
                  <!--  <label for="sel1">Select list (select one):</label>-->
      <select class="form-control" id="beer_id" name="beer_id">
        <option value="0">Select Beer </option>
     <?php  if( $beerAry ){
                          foreach ($beerAry   as $tuple) {
                          echo '<option value="'.$tuple['itemid'].'">'.$tuple['itemname'].'</option>';
                        }
                      }
                      ?>
      </select>
      <input type="hidden" name="action" id="action" value="<?php echo $action=isset($_GET['barid'])? 'update' : 'add'?>">
                   <!-- <label for="name">Drinker ID</label>-->
                  </div>
                
                </div>
                 
              </div>
            </div>
<?php }else{?>
  
                    <input type="hidden" name="bar_id" id="bar_id" value="<?php echo $value= (isset($barid))? $barid :  '' ;?>">
                    <input type="hidden" name="beer_id" id="beer_id" value="<?php echo $value= (isset($itemid))? $itemid :  '' ;?>">
                    
<?php }?>
             
          
               
           
            <button onclick="update(<?php echo $params=isset($_GET['barid'])? $barid.','.$itemid :""?>)" class="btn btn-primary"><?php echo $action=isset($_GET['barid'])? 'Update' : 'Add';?></button>
           
          
        </div>
      </div>
    </div>
        
              <!-- <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div> -->
            </div>


</div>
        <!-- /.container-fluid -->

        <!-- Sticky Footer -->
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © Your Website 2018</span>
            </div>
          </div>
        </footer>


 </div>
      <!-- /.content-wrapper -->
         </div>
    <!-- /#wrapper -->

        

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="login.html">Logout</a>
          </div>
        </div>
      </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

   
    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>

   
   
    <!-- Make table row clickable -->
    <script type="text/javascript">
      function update(id) {
var action= $("#action").val();
       var data= {barid:$("#bar_id").val(), itemid:$("#beer_id").val(),price:$("#price").val(),action:$("#action").val()};
       //return;
       $.ajax({url: "frequents_ajax.php", 
              method:"post",
              data: data,
              success: function(result){
                  if(result==1 ){
                    alert("successfully "+action+"ed");
                    location.reload();
              } else {
                  alert(result);  
              }

      }
    });
     } 
    $(document).ready(function($) {
        $(".clickable-row").click(function() {
            window.location = $(this).data("href");
        });
    });
    </script>
  </body>

</html>
