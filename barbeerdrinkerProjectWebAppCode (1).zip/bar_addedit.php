<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Bar</title>

    <!-- Bootstrap core CSS-->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Page level plugin CSS-->
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin.css" rel="stylesheet">
  </head>

  <body id="page-top">

    <?php 
      include ("layout/navigation-bar.php");
    ?>
    <div id="wrapper">
     
     
      <?php 
        include ("layout/sidebar.php");
      ?>
      <?php 
      if($_GET){
        include("model/Bars.php");
        $bars = new Bars(); 
        $id=$_GET['id'];
        $temp = $bars->getBar($id);
        $barAry = mysqli_fetch_assoc($temp);
        //print_r($drinkerAry);

      }  
      ?>
 <div id="content-wrapper">

        <div class="container-fluid">
<div class="container">
      <div class="card  mx-auto mt-10">
        <div class="card-header">Bar's Form</div>
        <div class="card-body">
          <!--<form  action="drinker_update.php" method="POST">-->
            <!--<form>-->
             <div class="form-group">
              <div class="form-row">
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="text" id="barname" name="barname" class="form-control" placeholder="Bar Name" required="required" autofocus="autofocus" value="<?php echo $value= (isset($barAry['barname']))?  $barAry['barname'] :  '' ;?>">
                    <label for="barname">Name</label>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="text" id="address" name="address" class="form-control" placeholder="Address" required="required" autofocus="autofocus" value="<?php echo $value= (isset($barAry['address']))?  $barAry['address'] :  '' ;?>">
                    <label for="address">Address</label>
                  </div>
                </div>
              </div>
            </div>
                <div class="form-group">
              <div class="form-row">
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="text" id="city" name="city" class="form-control" placeholder="City" required="required" autofocus="autofocus" value="<?php echo $value= (isset($barAry['city']))?  $barAry['city'] :  '' ;?>">
                    <label for="city">City</label>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="text" id="state" name="state" class="form-control" placeholder="State" required="required" autofocus="autofocus" value="<?php echo $value= (isset($barAry['state']))?  $barAry['state'] :  '' ;?>">
                    <label for="state">State</label>
                  </div>
                </div>
              </div>
            </div>
            <div class="form-group">
              <div class="form-row">
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="text" id="phone" name="phone" class="form-control" placeholder="Phone" required="required" autofocus="autofocus" value="<?php echo $value= (isset($barAry['phone']))?  $barAry['phone'] :  '' ;?>">
                    <label for="phone">Phone</label>
                    
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="text" id="license" name="license" class="form-control" placeholder="license" required="required" autofocus="autofocus" value="<?php echo $value= (isset($barAry['license']))?  $barAry['license'] :  '' ;?>">
                    <label for="state">License</label>
                  </div>
                </div>
              </div>
            </div>

             <div class="form-group">
              <div class="form-row">
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="text" id="open_time" name="open_time" class="form-control" placeholder="Open Time" required="required" autofocus="autofocus" value="<?php echo $value= (isset($barAry['open_time']))?  $barAry['open_time'] :  '' ;?>">
                    <label for="open_time">Open Time</label>
                        </div>
                </div>
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="text" id="close_time" name="close_time" class="form-control" placeholder="license" required="required" autofocus="autofocus" value="<?php echo $value= (isset($barAry['close_time']))?  $barAry['close_time'] :  '' ;?>">
                    <label for="close_time">Close Time</label>
                    <input type="hidden" name="id" id="id" value="<?php echo $value= (isset($id))? $id :  '' ;?>">
                    <input type="hidden" name="action" id="action" value="<?php echo $action=isset($_GET['id'])? 'update' : 'add'?>">
              
                  </div>
                </div>
              </div>
            </div>
           
           
            <button onclick="update(<?php echo $id;?>)" class="btn btn-primary"><?php echo $action=isset($_GET['id'])? 'Update' : 'Add';?></button>
           
          
        </div>
      </div>
    </div>
        
              <!-- <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div> -->
            </div>


</div>

        <!-- /.container-fluid -->

        <!-- Sticky Footer -->
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © Your Website 2018</span>
            </div>
          </div>
        </footer>


 </div>
      <!-- /.content-wrapper -->
         </div>
    <!-- /#wrapper -->

        

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="login.html">Logout</a>
          </div>
        </div>
      </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

   
    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>

   
   
    <!-- Make table row clickable -->
    <script type="text/javascript">
      function update(id){
var action= $("#action").val();
       var data= { id:$("#id").val(), barname:$("#barname").val(),license:$("#license").val(), address:$("#address").val(), city:$("#city").val(), state:$("#state").val(),phone:$("#phone").val(),action:$("#action").val(),open_time:$("#open_time").val(),close_time:$("#close_time").val()};
       //alert(data);
       //return;
       $.ajax({url: "bar_ajax.php", 
              method:"post",
              data: data,
              success: function(result){
                  if(result==1 ){
                    alert("successfully "+action+"ed");
                    location.reload();
              } else {
                  alert(result);  
              }

      }
    });
     }
    $(document).ready(function($) {
        $(".clickable-row").click(function() {
            window.location = $(this).data("href");
        });
    });
    </script>
  </body>

</html>
