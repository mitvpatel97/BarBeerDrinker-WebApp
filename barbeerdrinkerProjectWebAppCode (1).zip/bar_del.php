<?php

include("model/Bars.php");
//echo $_GET['id'];
         $bars = new Bars();
         //echo "hello";die; 
         $result = $bars->delete($_GET['id']);
         echo $result;

?>