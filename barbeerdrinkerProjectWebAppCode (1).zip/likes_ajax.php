<?php

//print_r($_POST);
include("model/Likes.php");
        $likes = new Likes(); 

if($_POST['action']=="update") {
unset($_POST['action']);
//print_r($_POST);die;
echo $likes->update($_POST);

}else if ($_POST['action']=="add"){

	unset($_POST['action']);
	//print_r($_POST);die;
	echo $likes->add($_POST);
}else{

}

?>

