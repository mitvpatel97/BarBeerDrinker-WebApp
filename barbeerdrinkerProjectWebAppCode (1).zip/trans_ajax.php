<?php 
//print_r($_POST);
include("model/Transaction.php");
        $Transactions = new Transactions(); 

if($_POST['action']=="update") {
unset($_POST['action']);
$id=$_POST['id'];
unset($_POST['id']);
//print_r($_POST);die;
echo $Transactions->update($_POST,$id);

}else if ($_POST['action']=="add"){

	unset($_POST['action']);
	unset($_POST['id']);
	//print_r($_POST);die;
	echo $Transactions->add($_POST);
}else{

}

?>